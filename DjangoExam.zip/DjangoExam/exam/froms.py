# forms.py
from django import forms
from .models import QuestionBank,Teacher

class QuestionBankForm(forms.ModelForm):
    class Meta:
        model = QuestionBank
        fields = '__all__'  # 根据需要调整
# forms.py
from django import forms
from .models import Course,CourseManager

class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = '__all__'  # 或者根据需要指定具体字段

from .models import Student
class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = '__all__'  # 或者根据需要指定具体字段
from django import forms
from .models import Teacher

class TeacherForm(forms.ModelForm):
    class Meta:
        model = Teacher
        fields = ['academy', 'major', 'teacher_id', 'name', 'age', 'sex', 'pwd']

    def clean_teacher_name(self):
        # 检查新的教师姓名是否为空
        teacher_name = self.cleaned_data['name']
        if not teacher_name:
            raise forms.ValidationError("新教师姓名是必需的。")
        return teacher_name

    def save(self, commit=True):
        # 覆盖save方法以更新教师信息
        teacher = super().save(commit=False)
        teacher.age = self.cleaned_data['age']
        teacher.sex = self.cleaned_data['sex']
        teacher.teacher_id = self.cleaned_data['teacher_id']
        teacher.pwd = self.cleaned_data['pwd']

        if commit:
            teacher.save()

        return teacher
# froms.py
from django import forms
from .models import CourseManager

class CourseManagerForm(forms.ModelForm):
    class Meta:
        model = CourseManager
        fields = ['name', 'age', 'sex', 'pwd']

    def clean_name(self):
        # 检查新的教务人员姓名是否为空
        manager_name = self.cleaned_data['name']
        if not manager_name:
            raise forms.ValidationError("新教务人员姓名是必需的。")
        return manager_name

    def save(self, commit=True):
        # 覆盖save方法以更新教务人员信息
        manager = super().save(commit=False)
        manager.age = self.cleaned_data['age']
        manager.sex = self.cleaned_data['sex']
        manager.pwd = self.cleaned_data['pwd']

        if commit:
            manager.save()

        return manager
