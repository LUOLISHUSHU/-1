from .import views
from django.contrib import admin
from django.urls import path,re_path
# from django.conf.urls import url
from exam import views
app_name = 'exam'
urlpatterns = [


    path(r'',views.index),#默认访问首页
    path('index/',views.index, name="index"),
    path('studentLogin/',views.studentLogin,name='studentLogin'),#学生登录
    path('startExam/',views.startExam,name='startExam'),#开始考试,
    path('calculateGrade/',views.calculateGrade,name='calculateGrade'),#考试评分
    path( 'stulogout/',views.stulogout,name='stulogout'),# 学生退出登录
    path("userfile/" ,views.userfile,name='userfile'),# 个人信息
    path('examinfo/',views.examinfo,name='examinfo'),# 考试信息
    path('admin_dashboard/', views.admin_dashboardView.as_view(), name='admin_dashboard'),
    path('adminlogin/',views.adminlogin.as_view(),name='adminlogin'),
    path('teacherLogin/',views.teacherLogin,name='teacherLogin'),
    path('paper/',views.paper,name='paper'),
    path('coursemanagerLogin/',views.coursemanagerLogin,name='coursemanagerLogin'),
    path('coursemanager/',views.coursemanager,name='coursemanager'),
    path('coursemanager/<int:academy_id>/', views.coursemanager, name='delete_academy'),
    path('add_question_bank/', views.add_question_bank, name='add_question_bank'),
    path('delete_course/<int:course_id>/', views.delete_course, name='delete_course'),
    path('delete_student/<int:sid>/', views.delete_student, name='delete_student'),
    path('edit_course', views.edit_course, name='edit_course'),
    path('edit_student', views.edit_student, name='edit_student'),
    path('delete_question_bank/<int:id>/', views.delete_question_bank, name='delete_question_bank'),
    path('delete_test_paper/<int:test_paper_id>/', views.delete_test_paper, name='delete_test_paper'),
    path('edit_teacher/<int:teacher_id>/', views.edit_teacher, name='edit_teacher'),
    path('edit_course_manager/<int:manager_id>/', views.edit_course_manager, name='edit_course_manager'),
    # path('edit_delete_coursemanagerr/<int:course_manager>/', views.edit_teacher, name='edit_teacher'),

]