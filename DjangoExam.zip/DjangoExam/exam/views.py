from django.shortcuts import render,HttpResponse,redirect,reverse
from  . import models
from datetime import datetime
from django.views import View
from django.contrib.auth import authenticate
from django.contrib.auth import login,logout
from django.views.decorators.csrf import csrf_exempt

# Create your views here.
# 学生登录
def studentLogin(request):
    if request.method == 'POST':
        # 获取表单信息
        sid = request.POST.get('sid')
        password = request.POST.get('password')
        print("sid", sid, "password", password)

        # 通过学号获取该学生实体
        student = models.Student.objects.get(sid=sid)
        print(student)

        if password == student.pwd:  # 登录成功
            request.session['username'] = sid  # user的值发送给session里的username
            request.session['is_login'] = True  # 认证为真

            # 查询考试信息
            paper = models.TestPaper.objects.filter(major=student.major)

            # 查询成绩信息
            grade = models.Record.objects.filter(sid=student.sid)

            # 渲染index模板
            return render(request, 'index.html', {'student': student, 'paper': paper, 'grade': grade})
        else:
            return render(request, 'login.html', {'message': '密码不正确'})
    elif request.method == 'GET':
        return render(request, 'login.html')
    else:
        return HttpResponse("请使用GET或POST请求数据")

def index(request):
    if request.session.get('is_login', None):
        username = request.session.get('username', None)
        try:
            student = models.Student.objects.get(sid=username)
            paper = models.TestPaper.objects.filter(major=student.major)
            return render(request, 'index.html', {'student': student, 'paper': paper})
        except models.Student.DoesNotExist:
            # 处理找不到学生记录的情况，可以返回一个错误页面或者重定向到其他地方
            return render(request, 'index.html', {'message': '找不到匹配的学生记录'})
    else:
        return render(request, "index.html")


def userfile(request):
    if request.session.get('is_login', None):  # 若session认证为真
        username = request.session.get('username', None)
        print(username)
        student = models.Student.objects.get(sid=username)

        # 查询考试信息
        paper = models.TestPaper.objects.filter(major=student.major)

        return render(request, 'userfile.html', {'student': student})


def stulogout(request):
     # logout(request)
     request.session.clear()
     url = reverse('exam:index')

     return redirect(url)


# 考试信息
def startExam(request):
    sid = request.GET.get('sid')
    title = request.GET.get('title')  # 试卷名字 唯一
    subject1 = request.GET.get('subject')  # 考试科目

    # 获取学生信息
    student = models.Student.objects.get(sid=sid)

    # 试卷信息
    paper = models.TestPaper.objects.filter(title=title, course__course_name=subject1)


    context = {
        'student': student,
        'paper': paper,
        'title': title,
        'subject': subject1,
        'count': paper.count()  # 数据表中数据的条数
    }

    return render(request, 'exam.html', context=context)



def examinfo(request):
    if request.session.get('is_login', None):  # 若session认证为真
        username = request.session.get('username', None)
        student = models.Student.objects.get(sid=username)
        # 查询成绩信息
        grade = models.Record.objects.filter(sid=student.sid)
        return render(request, 'examinfo.html', {'student': student, 'grade': grade})
    else:
        return render(request, 'examinfo.html')




# 计算考试成绩
@csrf_exempt
def calculateGrade(request):
    if request.method == 'POST':
        sid = request.POST.get('sid')
        subject1 = request.POST.get('subject')
        student = models.Student.objects.get(sid=sid)
        paper = models.TestPaper.objects.filter(major=student.major)
        grade = models.Record.objects.filter(sid=student.sid)
        course = models.Course.objects.filter(course_name=subject1).first()
        now =  datetime.now()
        # 计算考试成绩
        questions = models.TestPaper.objects.filter(course__course_name=subject1).\
            values('pid').values('pid__id','pid__answer','pid__score')

        stu_grade = 0  # 初始化一个成绩
        for p in questions:
            qid = str(p['pid__id'])
            stu_ans = request.POST.get(qid)
            cor_ans = p['pid__answer']
            if stu_ans == cor_ans:
                stu_grade += p['pid__score']
        models.Record.objects.create(sid_id=sid, course_id=course.id, grade=stu_grade,rtime=now)
        context = {
            'student': student,
            'paper': paper,
            'grade': grade
        }
        return render(request, 'index.html', context=context)




class adminlogin(View):

    def get(self, request, *args, **kwargs):
        return render(request, 'adminlogin.html')

    def post(self, request, *args, **kwargs):
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            next_page = request.GET.get('next', '')
            if next_page:
                return HttpResponseRedirect(next_page)
            return HttpResponseRedirect(reverse('exam:admin_dashboard'))
        return render(request, 'adminlogin.html', {
            'msg': '用户名或密码错误！'
        })
class adminlogout(View):
    def get(self, request, *args, **kwargs):
        logout(request)
        return HttpResponseRedirect(reverse('exam:index'))

from django.shortcuts import render, HttpResponse, redirect, reverse,HttpResponseRedirect
from . import models
from django.contrib.auth.mixins import LoginRequiredMixin
class admin_dashboardView(LoginRequiredMixin, View):
    login_url = '/login/'

    def get(self, request, *args, **kwargs):
        # 获取学院、专业、教师、教务人员列表
        academies = models.Academy.objects.all()
        majors = models.Major.objects.all()
        teachers = models.Teacher.objects.all()
        course_managers = models.CourseManager.objects.all()

        return render(request, 'admin_dashboard.html', {
            'teachers': teachers,
            'academies': academies,
            'majors': majors,
            'course_managers': course_managers
        })

    def post(self, request, *args, **kwargs):
        action = request.POST.get('action')

        if action == 'add_teacher':
            try:
                # 处理添加教师的逻辑
                teacher_name = request.POST.get('teacher_name')
                teacher_age = request.POST.get('teacher_age')
                teacher_sex = request.POST.get('teacher_sex')
                academy_id = int(request.POST.get('academy_id'))
                major_id = int(request.POST.get('major_id'))
                teacher_Id = request.POST.get('teacher_Id')
                password = request.POST.get('password')

                academy = models.Academy.objects.get(id=academy_id)
                major = models.Major.objects.get(id=major_id)

                # 创建一个新的 teacher 并关联 academy 和 major
                teacher = models.Teacher.objects.create(
                    name=teacher_name,
                    age=teacher_age,
                    sex=teacher_sex,
                    academy=academy,
                    major=major,
                    teacher_id=teacher_Id,
                    pwd=password,
                )

                return redirect('exam:admin_dashboard')
            except Exception as e:
                return HttpResponse(f'创建失败: {str(e)}')

        elif action == 'add_course_manager':
            try:
                # 处理添加教务人员的逻辑
                manager_id = request.POST.get('manager_id')
                course_manager_name = request.POST.get('course_manager_name')
                course_manager_age = request.POST.get('course_manager_age')
                course_manager_sex = request.POST.get('course_manager_sex')
                course_manager_pwd = request.POST.get('course_manager_pwd')

                # 创建一个新的 CourseManager
                course_manager = models.CourseManager.objects.create(
                    manager_id=manager_id,
                    name=course_manager_name,
                    age=course_manager_age,
                    sex=course_manager_sex,
                    pwd=course_manager_pwd,
                )

                return redirect('exam:admin_dashboard')
            except Exception as e:
                return HttpResponse(f'创建失败: {str(e)}')

        elif action == 'delete_teacher':
            try:
                # 处理删除教师的逻辑
                teacher_id_to_delete = request.POST.get('teacher_to_delete')
                teacher_to_delete = models.Teacher.objects.get(id=teacher_id_to_delete)
                teacher_to_delete.delete()
                return redirect('exam:admin_dashboard')
            except Exception as e:
                return HttpResponse(f'删除失败: {str(e)}')

        elif action == 'delete_coursemanager':
            try:

                coursemanager_to_delete = request.POST.get('coursemanager_to_delete')
                coursemanager_delete = models.CourseManager.objects.get(id=coursemanager_to_delete)
                coursemanager_delete.delete()
                return redirect('exam:admin_dashboard')
            except Exception as e:
                return HttpResponse(f'删除失败: {str(e)}')

        return HttpResponse('无效的请求方法')



from django.shortcuts import render, redirect
from django.http import HttpResponseNotFound
from .models import Teacher,CourseManager
from .froms import TeacherForm,CourseManagerForm # 请确保导入正确的表单类

def edit_teacher(request, teacher_id):
    try:
        teacher = Teacher.objects.get(id=teacher_id)
    except Teacher.DoesNotExist:
        return HttpResponseNotFound("找不到指定的教师。")

    if request.method == 'POST':
        form = TeacherForm(request.POST, instance=teacher)
        if form.is_valid():
            form.save()
            return redirect('exam:admin_dashboard')
    else:
        form = TeacherForm(instance=teacher)

    return render(request, 'edit_teacher.html', {'form': form, 'teacher': teacher})

from django.shortcuts import render, redirect, get_object_or_404
from .models import CourseManager
from .froms import CourseManagerForm

def edit_course_manager(request, manager_id):
    course_manager = get_object_or_404(CourseManager, id=manager_id)

    if request.method == 'POST':
        form = CourseManagerForm(request.POST, instance=course_manager)
        if form.is_valid():
            form.save()
            return redirect('exam:admin_dashboard')
    else:
        form = CourseManagerForm(instance=course_manager)

    return render(request, 'edit_coursemanager.html', {'form': form, 'course_manager': course_manager})





def teacherLogin(request):
    if request.method == 'POST':
        # 获取表单信息
        teacher_id = request.POST.get('teacher_id')
        password = request.POST.get('password')
        print("teacher_id", teacher_id, "password", password)

        # 通过学号获取该学生实体
        teacher = models.Teacher.objects.get(teacher_id=teacher_id)
        print(teacher)

        if password == teacher.pwd:  # 登录成功
            request.session['username'] = teacher_id
            request.session['is_login'] = True

            # 使用 redirect 函数重定向到 coursemanager 页面
            return redirect('exam:paper')
        else:
            return render(request, 'login_teacher.html', {'message': '密码不正确'})
    elif request.method == 'GET':
        return render(request, 'login_teacher.html')
    else:
        return HttpResponse("请使用GET或POST请求数据")



def paper(request):
    if request.method == 'GET':
        # 获取科目、专业和题库列表
        courses = models.Course.objects.all()
        majors = models.Major.objects.all()
        question_banks = models.QuestionBank.objects.all()
        test_papers = models.TestPaper.objects.all()  # 添加这一行
        return render(request, 'teacher_admin.html', {'courses': courses, 'majors': majors, 'question_banks': question_banks, 'test_papers': test_papers})
    elif request.method == 'POST':
        # 处理 POST 请求，添加试卷
        action = request.POST.get('action')

        if action == 'add_test_paper':
            try:
                title = request.POST.get('title')
                course_id = request.POST.get('course_id')
                major_id = request.POST.get('major_id')
                time = request.POST.get('time')
                examtime = request.POST.get('examtime')
                question_banks_ids = request.POST.getlist('question_banks')

                course = models.Course.objects.get(id=course_id)
                major = models.Major.objects.get(id=major_id)
                question_banks = models.QuestionBank.objects.filter(id__in=question_banks_ids)

                # 创建一个新的 TestPaper 并关联 course、major 和 question_banks
                test_paper = models.TestPaper.objects.create(
                    title=title,
                    course=course,
                    major=major,
                    time=time,
                    examtime=examtime,
                )

                test_paper.pid.set(question_banks)  # 设置多对多关系

                return redirect('exam:paper')

            except models.Course.DoesNotExist:
                return HttpResponse(f'课程ID {course_id} 不存在，请检查数据库。')
            except Exception as e:
                return HttpResponse(f'创建失败: {str(e)}')



from django.contrib import messages
from .models import TestPaper


def delete_test_paper(request, test_paper_id):
    test_paper = get_object_or_404(TestPaper, id=test_paper_id)

    if request.method == 'POST':
        test_paper.delete()
        messages.success(request, '试卷删除成功.')

    return redirect('exam:paper')


from django.http import HttpResponse
from . import models  # 导入你的模型

def coursemanagerLogin(request):
    if request.method == 'POST':
        # 获取表单信息
        manager_id = request.POST.get('manager_id')
        password = request.POST.get('password')

        try:
            manager = models.CourseManager.objects.get(manager_id=manager_id)
        except models.CourseManager.DoesNotExist:
            return render(request, 'login_coursemanager.html', {'message': '用户名不存在'})

        if password == manager.pwd:  # 登录成功
            request.session['username'] = manager_id
            request.session['is_login'] = True

            # 使用 redirect 函数重定向到 coursemanager 页面
            return redirect('exam:coursemanager')
        else:
            return render(request, 'login_coursemanager.html', {'message': '密码不正确'})

    elif request.method == 'GET':
        return render(request, 'login_coursemanager.html')

    else:
        return HttpResponse("请使用GET或POST请求数据")




from django.shortcuts import render, redirect
from .models import Academy, Major

def coursemanager(request):
    if request.method == 'GET':
        academies = Academy.objects.all()
        majors = Major.objects.all()
        return render(request, 'coursemanager.html', {'academies': academies, 'majors': majors})

    elif request.method == 'POST':
        # 处理添加学院的表单提交
        if 'academy_name' in request.POST:
            academy_name = request.POST.get('academy_name')
            new_academy = Academy(name=academy_name)
            new_academy.save()

        # 处理添加专业的表单提交
        elif 'major_name' in request.POST:
            academy_id = request.POST.get('academy_id')
            major_name = request.POST.get('major_name')
            Major.objects.create(academy_id=academy_id, major=major_name)

        elif 'delete_academy' in request.POST:
            academy_id = request.POST.get('delete_academy')
            academy = Academy.objects.get(id=academy_id)
            academy.delete()

        elif 'delete_major' in request.POST:
            major_id = request.POST.get('delete_major')
            major = Major.objects.get(id=major_id)
            major.delete()

        return redirect('exam:coursemanager')

    academies = Academy.objects.all()
    majors = Major.objects.all()
    return render(request, 'coursemanager.html', {'academies': academies, 'majors': majors})





# views.py
from django.shortcuts import render, redirect
from .models import Course
from .froms import CourseForm

def edit_course(request):
    all_courses = Course.objects.all()

    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('exam:coursemanager')
    else:
        form = CourseForm()

    return render(request, 'edit_course.html', {'form': form, 'all_courses': all_courses})


from django.shortcuts import render, redirect, get_object_or_404
def delete_course(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    if request.method == 'POST':
        course.delete()
    return redirect('exam:edit_course')

# views.py
from django.shortcuts import render, redirect
from .froms import QuestionBankForm





def add_question_bank(request):
    try:
        question_banks = QuestionBank.objects.all()
    except Exception as e:
        # 在发生异常时记录错误信息
        print(f"Error fetching question banks: {e}")
        question_banks = []

    if request.method == 'POST':
        form = QuestionBankForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('exam:add_question_bank')
    else:
        form = QuestionBankForm()

    return render(request, 'add_question_bank.html', {'form': form, 'question_banks': question_banks})

def delete_question_bank(request, id):
    question_banks = get_object_or_404(QuestionBank, id=id)

    if request.method == 'POST':
        question_banks.delete()
    return redirect('exam:add_question_bank')




from django.shortcuts import render, redirect, get_object_or_404
from .models import Student,QuestionBank
from .froms import StudentForm

def edit_student(request):
    all_students = Student.objects.all()

    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('exam:edit_student')
    else:
        form = StudentForm()

    return render(request, 'edit_student.html', {'form': form, 'all_students': all_students})

def delete_student(request, sid):
    student = get_object_or_404(Student, sid=sid)

    if request.method == 'POST':
        student.delete()
    return redirect('exam:edit_student')